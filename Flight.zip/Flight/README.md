Flight
======

IT 276 Project

Control the guy and get him to the right side of the level.

CONTROLS

E => left,
T => right,
NUM0 => jump, double jump, hold to glide
NUM+ => dash attack,
NUM1-9 => directional spear attacks,

1-5 => skip to level 1-5
6 => skip to boss fight
